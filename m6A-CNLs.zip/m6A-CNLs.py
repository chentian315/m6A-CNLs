from keras.layers.normalization import BatchNormalization
from keras.optimizers import SGD, Adam
# from group_norm import GroupNormalization
import random
import pandas as pd
import numpy as np
from Bio import SeqIO
from keras import regularizers
from keras.metrics import binary_accuracy
from sklearn.metrics import confusion_matrix,recall_score,matthews_corrcoef,roc_curve,roc_auc_score,auc,precision_recall_curve
import matplotlib.pyplot as plt
from keras.callbacks import EarlyStopping, ModelCheckpoint,ReduceLROnPlateau
import os, sys, copy, getopt, re, argparse
from sklearn.metrics import precision_recall_fscore_support
import tensorflow as tf
from keras import losses
import pickle
from sklearn.model_selection import KFold
from keras.engine import Layer, InputSpec
from keras import initializers
from keras import regularizers
from keras import constraints
from keras import backend as K
# from scipy import interp
from sklearn.utils.class_weight import compute_class_weight
from keras.utils.generic_utils import get_custom_objects
from keras.models import Model
from keras.layers import Dense, Dropout, Conv1D, Input,MaxPooling1D,Flatten,LeakyReLU,AveragePooling1D,concatenate,LSTM
from keras.layers.normalization import BatchNormalization
from keras.optimizers import SGD, Adam
import random
from Bio import SeqIO
from keras import regularizers
from keras.metrics import binary_accuracy
from sklearn.metrics import confusion_matrix,recall_score,matthews_corrcoef,roc_curve,roc_auc_score,auc,precision_recall_curve
from keras.callbacks import EarlyStopping, ModelCheckpoint,ReduceLROnPlateau
import os, sys, copy, getopt, re, argparse
from sklearn.metrics import precision_recall_fscore_support
from keras import losses
import pickle
os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID"   # see issue #152
os.environ["CUDA_VISIBLE_DEVICES"]="2"

class GroupNormalization(Layer):
    """Group normalization layer

    Group Normalization divides the channels into groups and computes within each group
    the mean and variance for normalization. GN's computation is independent of batch sizes,
    and its accuracy is stable in a wide range of batch sizes

    # Arguments
        groups: Integer, the number of groups for Group Normalization.
        axis: Integer, the axis that should be normalized
            (typically the features axis).
            For instance, after a `Conv2D` layer with
            `data_format="channels_first"`,
            set `axis=1` in `BatchNormalization`.
        epsilon: Small float added to variance to avoid dividing by zero.
        center: If True, add offset of `beta` to normalized tensor.
            If False, `beta` is ignored.
        scale: If True, multiply by `gamma`.
            If False, `gamma` is not used.
            When the next layer is linear (also e.g. `nn.relu`),
            this can be disabled since the scaling
            will be done by the next layer.
        beta_initializer: Initializer for the beta weight.
        gamma_initializer: Initializer for the gamma weight.
        beta_regularizer: Optional regularizer for the beta weight.
        gamma_regularizer: Optional regularizer for the gamma weight.
        beta_constraint: Optional constraint for the beta weight.
        gamma_constraint: Optional constraint for the gamma weight.

    # Input shape
        Arbitrary. Use the keyword argument `input_shape`
        (tuple of integers, does not include the samples axis)
        when using this layer as the first layer in a model.

    # Output shape
        Same shape as input.

    # References
        - [Group Normalization](https://arxiv.org/abs/1803.08494)
    """

    def __init__(self,
                 groups=32,
                 axis=-1,
                 epsilon=1e-5,
                 center=True,
                 scale=True,
                 beta_initializer='zeros',
                 gamma_initializer='ones',
                 beta_regularizer=None,
                 gamma_regularizer=None,
                 beta_constraint=None,
                 gamma_constraint=None,
                 **kwargs):
        super(GroupNormalization, self).__init__(**kwargs)
        self.supports_masking = True
        self.groups = groups
        self.axis = axis
        self.epsilon = epsilon
        self.center = center
        self.scale = scale
        self.beta_initializer = initializers.get(beta_initializer)
        self.gamma_initializer = initializers.get(gamma_initializer)
        self.beta_regularizer = regularizers.get(beta_regularizer)
        self.gamma_regularizer = regularizers.get(gamma_regularizer)
        self.beta_constraint = constraints.get(beta_constraint)
        self.gamma_constraint = constraints.get(gamma_constraint)

    def build(self, input_shape):
        dim = input_shape[self.axis]

        if dim is None:
            raise ValueError('Axis ' + str(self.axis) + ' of '
                             'input tensor should have a defined dimension '
                             'but the layer received an input with shape ' +
                             str(input_shape) + '.')

        if dim < self.groups:
            raise ValueError('Number of groups (' + str(self.groups) + ') cannot be '
                             'more than the number of channels (' +
                             str(dim) + ').')

        if dim % self.groups != 0:
            raise ValueError('Number of groups (' + str(self.groups) + ') must be a '
                             'multiple of the number of channels (' +
                             str(dim) + ').')

        self.input_spec = InputSpec(ndim=len(input_shape),
                                    axes={self.axis: dim})
        shape = (dim,)

        if self.scale:
            self.gamma = self.add_weight(shape=shape,
                                         name='gamma',
                                         initializer=self.gamma_initializer,
                                         regularizer=self.gamma_regularizer,
                                         constraint=self.gamma_constraint)
        else:
            self.gamma = None
        if self.center:
            self.beta = self.add_weight(shape=shape,
                                        name='beta',
                                        initializer=self.beta_initializer,
                                        regularizer=self.beta_regularizer,
                                        constraint=self.beta_constraint)
        else:
            self.beta = None
        self.built = True

    def call(self, inputs, **kwargs):
        input_shape = K.int_shape(inputs)
        tensor_input_shape = K.shape(inputs)

        # Prepare broadcasting shape.
        reduction_axes = list(range(len(input_shape)))
        del reduction_axes[self.axis]
        broadcast_shape = [1] * len(input_shape)
        broadcast_shape[self.axis] = input_shape[self.axis] // self.groups
        broadcast_shape.insert(1, self.groups)

        reshape_group_shape = K.shape(inputs)
        group_axes = [reshape_group_shape[i] for i in range(len(input_shape))]
        group_axes[self.axis] = input_shape[self.axis] // self.groups
        group_axes.insert(1, self.groups)

        # reshape inputs to new group shape
        group_shape = [group_axes[0], self.groups] + group_axes[2:]
        group_shape = K.stack(group_shape)
        inputs = K.reshape(inputs, group_shape)

        group_reduction_axes = list(range(len(group_axes)))
        group_reduction_axes = group_reduction_axes[2:]

        mean = K.mean(inputs, axis=group_reduction_axes, keepdims=True)
        variance = K.var(inputs, axis=group_reduction_axes, keepdims=True)

        inputs = (inputs - mean) / (K.sqrt(variance + self.epsilon))

        # prepare broadcast shape
        inputs = K.reshape(inputs, group_shape)
        outputs = inputs

        # In this case we must explicitly broadcast all parameters.
        if self.scale:
            broadcast_gamma = K.reshape(self.gamma, broadcast_shape)
            outputs = outputs * broadcast_gamma

        if self.center:
            broadcast_beta = K.reshape(self.beta, broadcast_shape)
            outputs = outputs + broadcast_beta

        outputs = K.reshape(outputs, tensor_input_shape)

        return outputs

    def get_config(self):
        config = {
            'groups': self.groups,
            'axis': self.axis,
            'epsilon': self.epsilon,
            'center': self.center,
            'scale': self.scale,
            'beta_initializer': initializers.serialize(self.beta_initializer),
            'gamma_initializer': initializers.serialize(self.gamma_initializer),
            'beta_regularizer': regularizers.serialize(self.beta_regularizer),
            'gamma_regularizer': regularizers.serialize(self.gamma_regularizer),
            'beta_constraint': constraints.serialize(self.beta_constraint),
            'gamma_constraint': constraints.serialize(self.gamma_constraint)
        }
        base_config = super(GroupNormalization, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))

    def compute_output_shape(self, input_shape):
        return input_shape

def calc(TN, FP, FN, TP):
    SN = TP / (TP + FN)
    SP = TN / (TN + FP)
    # Precision = TP / (TP + FP)
    ACC = (TP + TN) / (TP + TN + FN + FP)
    F1 = (2 * TP) / (2 * TP + FP + FN)
    MCC = (TP * TN - FP * FN) / pow((TP + FN) * (TP + FP) * (TN + FP) * (TN + FN), 0.5)
    return SN, SP, ACC, MCC

def chemical_properties(AA):
    one_hot_dict = {
        'A': [1, 1, 1],
        'U': [0, 0, 1],
        'G': [1, 0, 0],
        'C': [0, 1, 0]
    }
    coding_arr = np.zeros((len(AA),3), dtype=float)
    for m in range(len(AA)):
        coding_arr[m] = one_hot_dict[AA[m]]
    return coding_arr

def AA_ONE_HOT(AA):
    one_hot_dict = {
        'A': [1, 0, 0, 0],
        'C': [0, 1, 0, 0],
        'G': [0, 0, 1, 0],
        'U': [0, 0, 0, 1]
    }
    coding_arr = np.zeros((len(AA),4), dtype=float)
    for m in range(len(AA)):
        coding_arr[m] = one_hot_dict[AA[m]]
        # print(coding_arr[m])
    return coding_arr


def circular_ONE_HOT(AA):
    one_hot_dict = {
        'AA': [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        'AC': [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        'AG': [0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        'AU': [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        'CA': [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        'CC': [0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        'CG': [0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        'CU': [0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
        'GA': [0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
        'GC': [0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0],
        'GG': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0],
        'GU': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0],
        'UA': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
        'UC': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0],
        'UG': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0],
        'UU': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]
    }

    coding_arr = np.zeros((len(AA)-1,16), dtype=float)
    for m in range(len(AA)-1):
        coding_arr[m] = one_hot_dict[AA[m:m+2]]
        # print(coding_arr[m])
    return coding_arr


def circular_extraction(sample_name1, sample_name2):
    se_pp = (sample_name1)
    se_nn = (sample_name2)
    se_p = SeqIO.parse(se_pp, 'fasta')
    se_n = SeqIO.parse(se_nn, 'fasta')
    # print(str(se_p.seq))
    aa = len(list(se_p))
    bb = len(list(se_n))
    # print(aa)
    # print(bb)
    i = 0
    j = 0
    p = np.zeros((aa, 61, 16))
    p_label = np.zeros((aa, 2))
    n = np.zeros((bb, 61, 16))
    n_label = np.zeros((bb, 2))
    pp = p.copy()
    pp_label = p_label.copy()
    nn = n.copy()
    nn_label = n_label.copy()
    for my_pp in SeqIO.parse(se_pp,'fasta'):
        AA = str(my_pp.seq)[-1] + str(my_pp.seq)
        # print(len(AA))
        pp[i] = circular_ONE_HOT(AA)
        pp_label[i] = [1, 0]
        i += 1

    for my_nn in SeqIO.parse(se_nn,'fasta'):
        AA = str(my_nn.seq)[-1] + str(my_nn.seq)
        nn[j] = circular_ONE_HOT(AA)
        nn_label[j] = [0, 1]
        j += 1
    Z_Mays_xx_all = np.vstack([pp[:aa], nn[:bb]])
    Z_Mays_yy_all = np.vstack([pp_label[:aa], nn_label[:bb]])
    # Z_Mays_xx_all = Z_Mays_xx_all.reshape(len(Z_Mays_xx_all), -1)
    # Z_Mays_yy_all = Z_Mays_yy_all.reshape(len(Z_Mays_yy_all), -1)

    # Z_Mays_xx_all = nn[:bb]#np.vstack([pp[:aa], nn[:bb]])
    # Z_Mays_yy_all = nn_label[:bb]#np.vstack([pp_label[:aa], nn_label[:bb]])
    # print(Z_Mays_xx_all.shape)
    # print(Z_Mays_yy_all.shape)
    # print(Z_Mays_xx_all[1:2])
    # print(Z_Mays_yy_all[1:2])
    # np.save(sample_name + '_Binary__fuature_xx.npy', Z_Mays_xx_all)
    # np.save(sample_name + '3__fuature_yy.npy', Z_Mays_yy_all)
    return Z_Mays_xx_all, Z_Mays_yy_all


def first_feature_extraction(sample_name1, sample_name2):
    se_pp = (sample_name1)
    se_nn = (sample_name2)
    se_p = SeqIO.parse(se_pp, 'fasta')
    se_n = SeqIO.parse(se_nn, 'fasta')
    # print(se_p)
    aa = len(list(se_p))
    bb = len(list(se_n))
    # print(aa)
    # print(bb)
    i = 0
    j = 0
    p = np.zeros((aa, 61, 3))
    p_label = np.zeros((aa, 2))
    n = np.zeros((bb, 61, 3))
    n_label = np.zeros((bb, 2))
    pp = p.copy()
    pp_label = p_label.copy()
    nn = n.copy()
    nn_label = n_label.copy()
    # AA_ALL = []
    for my_pp in SeqIO.parse(se_pp,'fasta'):
        # print(my_pp.description)
        # print(type(my_pp))
        AA = str(my_pp.seq)
        # print(len(AA))
        # for ab in AA:
        #     print(ab)
        # AA_ALL.append(AA)
        # print(type)
        # print("----------------------")
        pp[i] = chemical_properties(AA)
        # print(pp[i])
        pp_label[i] = [1, 0]
        # print(pp_label[i])
        i += 1
    # print(AA_ALL)
    # print(type(AA_ALL))
    for my_nn in SeqIO.parse(se_nn,'fasta'):
        AA = str(my_nn.seq)
        nn[j] = chemical_properties(AA)
        nn_label[j] = [0, 1]
        j += 1

    Z_Mays_xx_all = np.vstack([pp[:aa], nn[:bb]])
    Z_Mays_yy_all = np.vstack([pp_label[:aa], nn_label[:bb]])
    # Z_Mays_xx_all = Z_Mays_xx_all.reshape(len(Z_Mays_xx_all), -1)
    # Z_Mays_yy_all = Z_Mays_yy_all.reshape(len(Z_Mays_yy_all), -1)

    print(Z_Mays_xx_all.shape)
    print(Z_Mays_yy_all.shape)

    # print(Z_Mays_xx_all[1:2])
    # print(Z_Mays_yy_all[1:2])
    # np.save(sample_name + 'chemical_properties__fuature_xx.npy', Z_Mays_xx_all)
    # np.save(sample_name + '1__fuature_yy.npy', Z_Mays_yy_all)
    return Z_Mays_xx_all, Z_Mays_yy_all


def third_feature_extraction(sample_name1, sample_name2):
    se_pp = (sample_name1)
    se_nn = (sample_name2)
    se_p = SeqIO.parse(se_pp, 'fasta')
    se_n = SeqIO.parse(se_nn, 'fasta')
    # print(str(se_p.seq))
    aa = len(list(se_p))
    bb = len(list(se_n))
    # print(aa)
    # print(bb)
    i = 0
    j = 0
    p = np.zeros((aa, 61, 4))
    p_label = np.zeros((aa, 2))
    n = np.zeros((bb, 61, 4))
    n_label = np.zeros((bb, 2))
    pp = p.copy()
    pp_label = p_label.copy()
    nn = n.copy()
    nn_label = n_label.copy()
    for my_pp in SeqIO.parse(se_pp,'fasta'):
        AA = str(my_pp.seq)
        pp[i] = AA_ONE_HOT(AA)
        pp_label[i] = [1, 0]
        i += 1

    for my_nn in SeqIO.parse(se_nn,'fasta'):
        AA = str(my_nn.seq)
        nn[j] = AA_ONE_HOT(AA)
        nn_label[j] = [0, 1]
        j += 1
    Z_Mays_xx_all = np.vstack([pp[:aa], nn[:bb]])
    Z_Mays_yy_all = np.vstack([pp_label[:aa], nn_label[:bb]])
    # Z_Mays_xx_all = Z_Mays_xx_all.reshape(len(Z_Mays_xx_all), -1)
    # Z_Mays_yy_all = Z_Mays_yy_all.reshape(len(Z_Mays_yy_all), -1)

    # Z_Mays_xx_all = nn[:bb]#np.vstack([pp[:aa], nn[:bb]])
    # Z_Mays_yy_all = nn_label[:bb]#np.vstack([pp_label[:aa], nn_label[:bb]])
    # print(Z_Mays_xx_all.shape)
    # print(Z_Mays_yy_all.shape)
    # print(Z_Mays_xx_all[1:2])
    # print(Z_Mays_yy_all[1:2])
    # np.save(sample_name + '_Binary__fuature_xx.npy', Z_Mays_xx_all)
    # np.save(sample_name + '3__fuature_yy.npy', Z_Mays_yy_all)
    return Z_Mays_xx_all, Z_Mays_yy_all


def build_model():
    input_shape1 = (61, 4)
    inputs1 = Input(shape=input_shape1)
    input_shape2 = (61, 16)
    inputs2 = Input(shape=input_shape2)
    input_shape3 = (61, 3)
    inputs3 = Input(shape=input_shape3)

    convLayer = Conv1D(filters=32, kernel_size=5, padding='same', kernel_regularizer=regularizers.l2(1e-3),
                       bias_regularizer=regularizers.l2(1e-4), activation='relu', input_shape=input_shape1)(inputs1)
    normalizationLayer = GroupNormalization(groups=4, axis=-1)(convLayer)
    convLayer2 = Conv1D(filters=16, kernel_size=3, padding='same', kernel_regularizer=regularizers.l2(1e-3),
                        bias_regularizer=regularizers.l2(1e-4), activation='relu', input_shape=input_shape1)(
        normalizationLayer)
    # convLayer2 = LSTM(16, return_sequences=False)(convLayer2)
    convLayer2 = LSTM(16, return_sequences=True)(convLayer2)
    # convLayer2 = LSTM(filters=16, kernel_size=3, activation='relu')(convLayer2)
    print("convLayer2", convLayer2.shape)
    flattenLayer = Flatten()(convLayer2)
    dropoutLayer = Dropout(0.5)(flattenLayer)
    denseLayer = Dense(8 * 3, activation='relu', kernel_regularizer=regularizers.l2(1e-3),
                       bias_regularizer=regularizers.l2(1e-4))(dropoutLayer)

    convLayer_b = Conv1D(filters=32, kernel_size=5, padding='same', kernel_regularizer=regularizers.l2(1e-3),
                         bias_regularizer=regularizers.l2(1e-4), activation='relu', input_shape=input_shape2)(inputs2)
    normalizationLayer_b = GroupNormalization(groups=4, axis=-1)(convLayer_b)
    convLayer2_b = Conv1D(filters=16, kernel_size=3, padding='same', kernel_regularizer=regularizers.l2(1e-3),
                          bias_regularizer=regularizers.l2(1e-4), activation='relu', input_shape=input_shape2)(
        normalizationLayer_b)
    # convLayer2_b = LSTM(16, return_sequences=False)(convLayer2_b)
    convLayer2_b = LSTM(16, return_sequences=True)(convLayer2_b)

    flattenLayer_b = Flatten()(convLayer2_b)
    dropoutLayer_b = Dropout(0.5)(flattenLayer_b)
    denseLayer_b = Dense(8 * 3, activation='relu', kernel_regularizer=regularizers.l2(1e-3),
                         bias_regularizer=regularizers.l2(1e-4))(dropoutLayer_b)

    convLayer_c = Conv1D(filters=32, kernel_size=5, padding='same', kernel_regularizer=regularizers.l2(1e-3),
                         bias_regularizer=regularizers.l2(1e-4), activation='relu', input_shape=input_shape3)(inputs3)
    normalizationLayer_c = GroupNormalization(groups=4, axis=-1)(convLayer_c)
    convLayer2_c = Conv1D(filters=16, kernel_size=3, padding='same', kernel_regularizer=regularizers.l2(1e-3),
                          bias_regularizer=regularizers.l2(1e-4), activation='relu', input_shape=input_shape3)(
        normalizationLayer_c)
    # convLayer2_c = LSTM(16, return_sequences=False)(convLayer2_c)
    convLayer2_c = LSTM(16, return_sequences=True)(convLayer2_c)

    flattenLayer_c = Flatten()(convLayer2_c)
    dropoutLayer_c = Dropout(0.5)(flattenLayer_c)
    denseLayer_c = Dense(8 * 3, activation='relu', kernel_regularizer=regularizers.l2(1e-3),
                         bias_regularizer=regularizers.l2(1e-4))(dropoutLayer_c)
    denseLayer_com = concatenate([denseLayer, denseLayer_c, denseLayer_b])
    outLayer = Dense(2, activation='sigmoid')(denseLayer_com)
    model = Model(inputs=[inputs1, inputs3, inputs2], outputs=outLayer)
    model.compile(loss='binary_crossentropy', optimizer=Adam(lr=0.0001), metrics=['binary_accuracy'])
    return model


def getMode():
    # pp = 'D:\Pycharm\PyCharm Community Edition 2020.1.4\holle world\ct\m6A_61_hg19_P(train).fasta'
    # nn = 'D:\Pycharm\PyCharm Community Edition 2020.1.4\holle world\ct\m6A_61_hg19_N(train).fasta'
    pp = 'dataset\m6A_61_hg19_P(train).fasta'
    nn = 'dataset\m6A_61_hg19_N(train).fasta'

    ##########
    # pp_test = 'D:\Pycharm\PyCharm Community Edition 2020.1.4\holle world\ct\m6A_61_hg19_P(test).fasta'
    # nn_test = 'D:\Pycharm\PyCharm Community Edition 2020.1.4\holle world\ct\m6A_61_hg19_N(test).fasta'
    pp_test = 'dataset\m6A_61_hg19_P(test).fasta'
    nn_test = 'dataset\m6A_61_hg19_N(test).fasta'
    ########

    Z_Mays_xx_all, Y = circular_extraction(pp, nn)
    Z_Mays_xx_all1, Z_Mays_yy_all1 = first_feature_extraction(pp, nn)
    Z_Mays_xx_all2, Z_Mays_yy_all2 = third_feature_extraction(pp, nn)
    X = np.concatenate((Z_Mays_xx_all2, Z_Mays_xx_all1, Z_Mays_xx_all), axis=2)

    ##########
    Z_Mays_xx_all0, test_Y = circular_extraction(pp_test, nn_test)
    Z_Mays_xx_all11, Z_Mays_yy_all11 = first_feature_extraction(pp_test, nn_test)
    Z_Mays_xx_all22, Z_Mays_yy_all22 = third_feature_extraction(pp_test, nn_test)
    test_X = np.concatenate((Z_Mays_xx_all22, Z_Mays_xx_all11, Z_Mays_xx_all0), axis=2)
    ##########

    kf = KFold(n_splits=5, shuffle=True,random_state=2002)
    # kf.get_n_splits(X)
    # print(kf.get_n_splits(X))
    TN, FP, FN, TP, AUC = [], [], [], [], []

    # ################ test独立测试集结果保存
    # TN1, FP1, FN1, TP1, AUC1 = [], [], [], [], []
    # #################

    labels = []
    probs = []
    num = 0
    for train_index, test_index in kf.split(X,Y):
        num += 1
        # print("TRAIN:", train_index, "TEST:", test_index)
        x_train, x_test = X[train_index], X[test_index]
        y_train, y_test = Y[train_index], Y[test_index]

        ###########模型移到了build_model中
        model = build_model()
        ##############

        model.fit([x_train[:,:,:4],x_train[:,:,4:7],x_train[:,:,7:]], y_train, batch_size=32, epochs=20, verbose=1)
        # model.fit([x_train[:,:,:4],x_train[:,:,4:7],x_train[:,:,7:]], y_train, batch_size=256, epochs=20, verbose=1)
        model.evaluate([x_test[:,:,:4],x_test[:,:,4:7],x_test[:,:,7:]], y_test, verbose=1)
        y_predict = model.predict([x_test[:,:,:4],x_test[:,:,4:7],x_test[:,:,7:]])
        # print(y_predict)
        # print(type(y_predict))
        probs += y_predict[:, 0].flatten().tolist()
        # print(len(probs))
        y_predict_class = np.argmin(y_predict, axis=1)
        y_test_class = np.argmin(y_test, axis=1)
        # print(type(y_predict_class))
        print(y_test_class)
        labels += y_test_class.flatten().tolist()
        # print(len(labels))
        # y_probs = model.predict_proba(x_test)  # 模型的预测得分
        # print(y_probs)

        tn, fp, fn, tp = confusion_matrix(y_test_class, y_predict_class).ravel()
        print("tn, fp, fn, tp={},{},{},{}".format(tn, fp, fn, tp))
        sn, sp, acc, mcc = calc(float(tn), float(fp), float(fn), float(tp))
        print('sn=%.4f' % sn, ',sp=%.4f' % sp, ',acc=%.4f' % acc, ',mcc=%.4f' % mcc)
        fpr, tpr, thresholds = roc_curve(y_test_class, y_predict[:, 0], pos_label=1)
        roc_auc = auc(fpr, tpr)  # auc为Roc曲线下的面积
        print('AUC=', roc_auc)

        # fpr1.append(fpr)
        # tpr1.append(tpr)
        AUC.append(roc_auc)
        TN.append(tn)
        FP.append(fp)
        FN.append(fn)
        TP.append(tp)
        del model

        # plt.figure()


    my_auc = np.sum(AUC, dtype=np.float64) / 5
    my_tn = np.sum(TN, dtype=np.float64)
    my_fp = np.sum(FP, dtype=np.float64)
    my_fn = np.sum(FN, dtype=np.float64)
    my_tp = np.sum(TP, dtype=np.float64)

    # print(labels)
    # print(probs)
    fpr1, tpr1, thresholds = roc_curve(labels, probs)
    print(type(fpr1))
    roc_auc1 = auc(fpr1, tpr1)  # auc为Roc曲线下的面积
    print('训练集五折叠交叉验证结果：')
    print("TN,FP,FN,TP={},{},{},{}".format(int(my_tn), int(my_fp), int(my_fn), int(my_tp)))
    sn, sp, acc, mcc = calc(my_tn, my_fp, my_fn, my_tp)
    print('sn=%.4f' % sn, ',sp=%.4f' % sp, ',acc=%.4f' % acc, ',mcc=%.4f' % mcc, ',roc_auc1=%.4f' % roc_auc1)
    # original_data = pd.read_excel('label_porbs.xlsx')
    # write_tap = []
    # write_tap.append([acc, sn, sp, mcc, roc_auc1])
    # df = pd.DataFrame(write_tap, columns=['Acc(%)', 'Sn(%)', 'Sp(%)', 'MCC', 'AUC'])
    # save_data = original_data.append(df)
    # save_data.to_excel(
    #     'label_porbs.xlsx',
    #     index=False)

    # np.save('D:\Pycharm\PyCharm Community Edition 2020.1.4\holle world\m6Am\m6Am41\结果\m6Am_cnn_fpr.npy', fpr1)
    # np.save('D:\Pycharm\PyCharm Community Edition 2020.1.4\holle world\m6Am\m6Am41\结果\m6Am_cnn_tpr.npy', tpr1)
    # print("小鼠总体")
    lw = 2
    plt.figure(figsize=(10, 10))
    plt.plot(fpr1, tpr1, lw=lw, label='ROC curve (AUC = %.4f)' % roc_auc1)  ###假正率为横坐标，真正率为纵坐标做曲线
    plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.0])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver operating characteristic example')
    plt.legend(loc="lower right")
    plt.savefig('m6A_train.pdf', dpi=300)
    plt.show()

    ##############独立测试集预测
    model = build_model()
    model.fit(x=[X[:, :, :4], X[:, :, 4:7], X[:, :, 7:]], y=Y,
              validation_data=([test_X[:, :, :4], test_X[:, :, 4:7], test_X[:, :, 7:]], test_Y), batch_size=32,
              epochs=20, verbose=1)
    # model.fit(x=[X[:, :, :4], X[:, :, 4:7], X[:, :, 7:]], y=Y,
    #           validation_data=([test_X[:, :, :4], test_X[:, :, 4:7], test_X[:, :, 7:]], test_Y), batch_size=256,
    #           epochs=20, verbose=1)

    model.evaluate([test_X[:, :, :4], test_X[:, :, 4:7], test_X[:, :, 7:]], test_Y, verbose=1)
    y_predict = model.predict([test_X[:, :, :4], test_X[:, :, 4:7], test_X[:, :, 7:]])
    # print(y_predict)
    # print(type(y_predict))
    probs += y_predict[:, 0].flatten().tolist()
    # print(len(probs))
    y_predict_class = np.argmin(y_predict, axis=1)
    y_test_class = np.argmin(test_Y, axis=1)
    # print(type(y_predict_class))
    print(y_test_class)
    labels += y_test_class.flatten().tolist()
    # print(len(labels))
    # y_probs = model.predict_proba(x_test)  # 模型的预测得分
    # print(y_probs)

    tn, fp, fn, tp = confusion_matrix(y_test_class, y_predict_class).ravel()
    print("tn, fp, fn, tp={},{},{},{}".format(tn, fp, fn, tp))
    sn1, sp1, acc1, mcc1 = calc(float(tn), float(fp), float(fn), float(tp))
    print('独立测试集sn=%.4f' % sn1, ',sp=%.4f' % sp1, ',acc=%.4f' % acc1, ',mcc=%.4f' % mcc1)
    fpr1, tpr1, thresholds1 = roc_curve(y_test_class, y_predict[:, 0], pos_label=1)
    roc_auc1 = auc(fpr1, tpr1)  # auc为Roc曲线下的面积
    print('AUC=', roc_auc1)

    lw = 2
    plt.figure(figsize=(10, 10))
    plt.plot(fpr1, tpr1, lw=lw, label='ROC curve (AUC = %.4f)' % roc_auc1)  ###假正率为横坐标，真正率为纵坐标做曲线
    plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.0])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver operating characteristic example')
    plt.legend(loc="lower right")
    plt.savefig('m6A_test.pdf', dpi=300)
    plt.show()
    #####################
    return None


if __name__ == "__main__":
    getMode()






